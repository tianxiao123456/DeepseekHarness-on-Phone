#!/usr/bin/env node
/**
 * DSH Phone launcher.
 *
 * Finds the installed DeepSeek Harness, publishes the bridge through a
 * Cloudflare quick tunnel (no account, no server configuration), then prints a
 * QR code and opens the pairing page.
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const net = require('node:net');
const http = require('node:http');
const crypto = require('node:crypto');
const { spawn, spawnSync } = require('node:child_process');

const PKG_DIR = path.dirname(__dirname);
const APP_DIR = path.join(PKG_DIR, 'app');
const BIN_DIR = path.join(PKG_DIR, 'bin');
const DATA_DIR = path.join(process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local'), 'DSH-Phone');
const CONFIG_FILE = path.join(DATA_DIR, 'config.json');
const PID_FILE = path.join(DATA_DIR, 'pids.json');

const argv = process.argv.slice(2);
const OPT = {};
for (let i = 0; i < argv.length; i += 1) {
  const a = argv[i];
  if (!a.startsWith('--')) continue;
  const key = a.slice(2);
  const next = argv[i + 1];
  if (next === undefined || next.startsWith('--')) OPT[key] = true;
  else { OPT[key] = next; i += 1; }
}

const NO_TUNNEL = OPT['no-tunnel'] === true || process.env.DSH_PHONE_NO_TUNNEL === '1';
const DEMO = OPT.demo === true || process.env.DSH_PHONE_DEMO === '1';
const CHILD = [];
let bridge = null;
let tunnel = null;
let publicUrl = '';
let stopping = false;

/* ------------------------------------------------------------------ */
/* look & feel                                                         */
/* ------------------------------------------------------------------ */

const ESC = '\x1b[';
const c = {
  dim: (s) => `${ESC}2m${s}${ESC}0m`,
  bold: (s) => `${ESC}1m${s}${ESC}0m`,
  blue: (s) => `${ESC}38;5;75m${s}${ESC}0m`,
  green: (s) => `${ESC}38;5;114m${s}${ESC}0m`,
  yellow: (s) => `${ESC}38;5;221m${s}${ESC}0m`,
  red: (s) => `${ESC}38;5;203m${s}${ESC}0m`,
  invert: (s) => `${ESC}7m${s}${ESC}0m`,
};

function banner(lines) {
  const width = Math.max(...lines.map((l) => displayWidth(l))) + 4;
  console.log('');
  console.log(c.blue('  ╭' + '─'.repeat(width) + '╮'));
  for (const line of lines) {
    console.log(c.blue('  │') + '  ' + line + ' '.repeat(Math.max(0, width - 2 - displayWidth(line))) + c.blue('│'));
  }
  console.log(c.blue('  ╰' + '─'.repeat(width) + '╯'));
  console.log('');
}

function displayWidth(s) {
  let n = 0;
  for (const ch of s.replace(/\x1b\[[0-9;]*m/g, '')) n += ch.charCodeAt(0) > 0x2e80 ? 2 : 1;
  return n;
}

function step(msg) { console.log('  ' + c.dim('·') + ' ' + msg); }
function ok(msg) { console.log('  ' + c.green('✓') + ' ' + msg); }
function warn(msg) { console.log('  ' + c.yellow('!') + ' ' + msg); }

/* A console window that is closed by the user (or killed) does not always run
 * exit handlers, so remember child pids and reap the previous run on start. */
function killStale() {
  try {
    const pids = JSON.parse(fs.readFileSync(PID_FILE, 'utf8'));
    for (const pid of pids) {
      if (pid && pid !== process.pid) {
        try { spawnSync('taskkill', ['/pid', String(pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true }); } catch { /* ignore */ }
      }
    }
  } catch { /* first run */ }
  try { fs.mkdirSync(DATA_DIR, { recursive: true }); fs.writeFileSync(PID_FILE, '[]'); } catch { /* ignore */ }
}

function rememberPids() {
  try {
    const pids = CHILD.map((c) => c && c.pid).filter(Boolean);
    fs.writeFileSync(PID_FILE, JSON.stringify(pids));
  } catch { /* ignore */ }
}

/* ------------------------------------------------------------------ */
/* locate DeepSeek Harness                                             */
/* ------------------------------------------------------------------ */

function candidateInstalls() {
  const list = [];
  if (OPT.cli) list.push({ cli: OPT.cli });
  if (process.env.DSH_PHONE_CLI) list.push({ cli: process.env.DSH_PHONE_CLI });
  try {
    const cfg = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
    if (cfg.cli) list.push({ cli: cfg.cli });
  } catch { /* no config yet */ }
  const roots = [
    process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, 'Programs', 'DeepSeek Harness'),
    process.env.ProgramFiles && path.join(process.env.ProgramFiles, 'DeepSeek Harness'),
    process.env['ProgramFiles(x86)'] && path.join(process.env['ProgramFiles(x86)'], 'DeepSeek Harness'),
    'E:\\Deepseek Harness',
    'D:\\Deepseek Harness',
    'C:\\Deepseek Harness',
  ].filter(Boolean);
  for (const root of roots) list.push({ cli: path.join(root, 'resources', 'runtime', 'cli', 'bin', 'dsh.cmd') });
  const which = spawnSync(process.platform === 'win32' ? 'where' : 'which', ['dsh'], { encoding: 'utf8' });
  if (which.status === 0 && which.stdout.trim()) {
    for (const line of which.stdout.split(/\r?\n/)) if (line.trim()) list.push({ cli: line.trim() });
  }
  return list;
}

function resolveCli() {
  for (const cand of candidateInstalls()) {
    if (cand.cli && fs.existsSync(cand.cli)) return cand.cli;
  }
  return null;
}

function rememberCli(cli) {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(CONFIG_FILE, JSON.stringify({ cli }, null, 2));
  } catch { /* best effort */ }
}

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

function freePort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.unref();
    srv.on('error', reject);
    srv.listen(0, '127.0.0.1', () => {
      const p = srv.address().port;
      srv.close(() => resolve(p));
    });
  });
}

function randomPin() {
  return String(crypto.randomInt(100000, 1000000));
}

function lanIp() {
  for (const [name, addrs] of Object.entries(os.networkInterfaces())) {
    for (const a of addrs || []) {
      if (a.family === 'IPv4' && !a.internal && !a.address.startsWith('169.254.')) {
        if (/vmware|virtualbox|vethernet|hyper-v|loopback|tailscale/i.test(name)) continue;
        return a.address;
      }
    }
  }
  return null;
}

function waitFor(predicate, timeoutMs, interval = 400) {
  const start = Date.now();
  return new Promise((resolve, reject) => {
    const tick = async () => {
      if (Date.now() - start > timeoutMs) { reject(new Error('timeout')); return; }
      try { if (await predicate()) { resolve(true); return; } } catch { /* retry */ }
      setTimeout(tick, interval);
    };
    tick();
  });
}

function getJson(url, timeout = 3000) {
  return new Promise((resolve, reject) => {
    const req = http.get(url, { timeout }, (res) => {
      let data = '';
      res.on('data', (d) => { data += d; });
      res.on('end', () => { try { resolve(JSON.parse(data)); } catch (e) { reject(e); } });
    });
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', reject);
  });
}

/* ------------------------------------------------------------------ */
/* cloudflared                                                         */
/* ------------------------------------------------------------------ */

function cloudflaredPath() {
  const local = path.join(BIN_DIR, 'cloudflared.exe');
  if (fs.existsSync(local)) return local;
  const cached = path.join(DATA_DIR, 'cloudflared.exe');
  if (fs.existsSync(cached)) return cached;
  return null;
}

async function downloadCloudflared() {
  const dest = path.join(DATA_DIR, 'cloudflared.exe');
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const url = 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe';
  step('首次运行：下载隧道组件 cloudflared (~55 MB)…');
  const res = await fetch(url, { redirect: 'follow' });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const total = Number(res.headers.get('content-length') || 0);
  const tmp = dest + '.part';
  const out = fs.createWriteStream(tmp);
  let got = 0;
  let lastTick = 0;
  for await (const chunk of res.body) {
    out.write(chunk);
    got += chunk.length;
    const now = Date.now();
    if (now - lastTick > 500) {
      lastTick = now;
      const pct = total ? Math.floor((got / total) * 100) : 0;
      process.stdout.write(`\r    ${pct}%  ${(got / 1048576).toFixed(1)} MB   `);
    }
  }
  await new Promise((r) => out.end(r));
  process.stdout.write('\r' + ' '.repeat(40) + '\r');
  fs.renameSync(tmp, dest);
  return dest;
}

/* ------------------------------------------------------------------ */
/* tunnels                                                             */
/* ------------------------------------------------------------------ */

function startSshTunnel(port) {
  const child = spawn('ssh', [
    '-T',
    '-o', 'StrictHostKeyChecking=no',
    '-o', 'UserKnownHostsFile=NUL',
    '-o', 'ExitOnForwardFailure=yes',
    '-o', 'ServerAliveInterval=25',
    '-o', 'ServerAliveCountMax=3',
    '-R', `80:127.0.0.1:${port}`,
    'nokey@localhost.run',
  ], { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
  CHILD.push(child);
  rememberPids();
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('ssh tunnel timeout')), 40000);
    let text = '';
    const fail = (reason) => {
      clearTimeout(timer);
      const tail = text.split(/\r?\n/).filter((l) => l.trim() && !l.includes('\u001b')).slice(-2).join(' ');
      reject(new Error(reason + (tail ? ': ' + tail.slice(0, 240) : '')));
    };
    const onData = (chunk) => {
      text += chunk.toString('utf8');
      const m = text.match(/https:\/\/([a-z0-9-]+)\.lhr\.life/i);
      if (m) {
        clearTimeout(timer);
        resolve({ child, url: m[0].replace(/\/$/, '') });
      }
    };
    child.stdout.on('data', onData);
    child.stderr.on('data', onData);
    child.on('exit', (code) => fail(`ssh exited (${code})`));
    child.on('error', (err) => fail(err.message));
  });
}

function startTunnel(port) {
  const bin = cloudflaredPath();
  if (!bin) throw new Error('cloudflared missing');
  const child = spawn(bin, ['tunnel', '--url', `http://127.0.0.1:${port}`, '--no-autoupdate'], {
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true,
  });
  CHILD.push(child);
  rememberPids();
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('tunnel timeout')), 45000);
    let text = '';
    const fail = (reason) => {
      clearTimeout(timer);
      const tail = text.split(/\r?\n/).filter((l) => /ERR|error|failed/i.test(l)).slice(-2).join(' ');
      reject(new Error(reason + (tail ? ': ' + tail.slice(0, 300) : '')));
    };
    const onData = (chunk) => {
      text += chunk.toString('utf8');
      // Match only the assigned tunnel host, never the api.trycloudflare.com endpoint.
      const m = text.match(/https:\/\/(?!api\.|update\.|www\.)([a-z0-9-]+)\.trycloudflare\.com/i);
      if (m) {
        clearTimeout(timer);
        resolve({ child, url: m[0].replace(/\/$/, '') });
      }
    };
    child.stdout.on('data', onData);
    child.stderr.on('data', onData);
    child.on('exit', (code) => fail(`cloudflared exited (${code})`));
  });
}

/* ------------------------------------------------------------------ */
/* QR                                                                  */
/* ------------------------------------------------------------------ */

function printQr(text) {
  try {
    const qrcode = require(path.join(APP_DIR, 'web', 'qrcode.js'));
    const qr = qrcode(0, 'M');
    qr.addData(text, 'Byte');
    qr.make();
    const ascii = qr.createASCII(1, 2);
    console.log(ascii.split('\n').map((l) => '  ' + l).join('\n'));
  } catch (err) {
    warn('无法在终端绘制二维码：' + err.message);
  }
}

/* ------------------------------------------------------------------ */
/* main                                                                */
/* ------------------------------------------------------------------ */

async function main() {
  console.log('');
  console.log('  ' + c.bold('🐋  DSH Phone') + c.dim('  ·  在手机上使用这台电脑的 DeepSeek Harness'));
  console.log('');

  killStale();

  let cli = resolveCli();
  if (!DEMO && !cli) {
    console.error('  ' + c.red('找不到 DeepSeek Harness。'));
    console.error('  请确认已安装桌面版，或用 --cli 指定 dsh.cmd 的完整路径。');
    process.exit(1);
  }
  if (cli) { rememberCli(cli); ok('Harness  ' + c.dim(cli)); }

  const port = await freePort();
  const pin = OPT.pin ? String(OPT.pin) : randomPin();
  let host = '127.0.0.1';

  if (!NO_TUNNEL) {
    step('建立公网隧道…');

    // 1) SSH reverse tunnel — Windows ships the client, no download, IPv4.
    for (let attempt = 1; attempt <= 2 && !publicUrl; attempt += 1) {
      try {
        const t = await startSshTunnel(port);
        tunnel = t.child;
        publicUrl = t.url;
        ok('公网地址 ' + c.blue(publicUrl));
      } catch (err) {
        if (attempt < 2) await new Promise((r) => setTimeout(r, 1500));
      }
    }

    // 2) Cloudflare quick tunnel as a fallback.
    if (!publicUrl) {
      let bin = cloudflaredPath();
      if (!bin && process.platform === 'win32') {
        try { bin = await downloadCloudflared(); ok('隧道组件已就绪'); }
        catch (err) { warn('下载 cloudflared 失败：' + err.message); }
      }
      if (bin) {
        for (let attempt = 1; attempt <= 3 && !publicUrl; attempt += 1) {
          try {
            const t = await startTunnel(port);
            tunnel = t.child;
            publicUrl = t.url;
            ok('公网地址 ' + c.blue(publicUrl));
          } catch (err) {
            if (attempt < 3) await new Promise((r) => setTimeout(r, 2000));
            else warn('Cloudflare 隧道不可用：' + err.message);
          }
        }
      }
    }

    if (!publicUrl) warn('公网隧道都没建立成功');
  }

  if (!publicUrl) {
    host = '0.0.0.0';
    const ip = lanIp();
    warn('未启用公网隧道，仅局域网可用');
    if (ip) ok('局域网地址 ' + c.blue(`http://${ip}:${port}`));
  }

  step('启动 Harness 桥接…');
  if (tunnel) {
    tunnel.on('exit', () => {
      if (!stopping) warn('公网隧道已断开；手机访问会失效，重启本窗口即可重连。');
    });
  }
  bridge = spawn(process.execPath, [
    path.join(APP_DIR, 'bridge.js'),
    '--port', String(port),
    '--host', host,
    '--pin', pin,
    '--public-url', publicUrl || `http://${lanIp() || '127.0.0.1'}:${port}`,
    ...(OPT.cwd ? ['--cwd', OPT.cwd] : []),
    ...(DEMO ? ['--demo'] : []),
    ...(cli ? ['--cli', cli] : []),
  ], { stdio: 'inherit', windowsHide: false });
  CHILD.push(bridge);
  rememberPids();
  bridge.on('exit', (code) => {
    if (code !== 0) warn(`桥接进程退出 (${code})`);
    cleanup(0);
  });

  await waitFor(async () => {
    const st = await getJson(`http://127.0.0.1:${port}/healthz`);
    return !!st.ok;
  }, 20000).catch(() => warn('桥接启动较慢，请稍候刷新'));

  const entry = `${publicUrl || `http://${lanIp() || '127.0.0.1'}:${port}`}/?k=${pin}`;
  banner([
    c.bold('手机打开下面的地址（扫码更快）'),
    '',
    c.blue(entry),
    '',
    `访问码  ${c.bold(pin)}   ` + c.dim(PUBLIC_URL_HINT()),
    c.dim('手机浏览器直接打开，无需安装 App'),
  ]);

  if (!DEMO) printQr(entry);

  console.log('  ' + c.dim('配对页已在电脑浏览器打开，用手机相机扫码即可。'));
  console.log('  ' + c.dim('保持这个窗口开启；关闭窗口 = 断开手机访问。'));
  console.log('');

  const pairUrl = `http://127.0.0.1:${port}/pair`;
  try {
    if (process.platform === 'win32') spawn('cmd', ['/c', 'start', '', pairUrl], { stdio: 'ignore', windowsHide: true, detached: true }).unref();
    else spawn('xdg-open', [pairUrl], { stdio: 'ignore', detached: true }).unref();
  } catch { /* ignore */ }
}

function PUBLIC_URL_HINT() {
  return publicUrl ? '公网 · 手机流量也能用' : '局域网 · 需与电脑同一 Wi-Fi';
}

function cleanup(code) {
  stopping = true;
  try { fs.writeFileSync(PID_FILE, '[]'); } catch { /* ignore */ }
  for (const child of CHILD) {
    try {
      if (child.pid) {
        if (process.platform === 'win32') spawnSync('taskkill', ['/pid', String(child.pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true });
        else child.kill('SIGTERM');
      }
    } catch { /* ignore */ }
  }
  process.exit(code);
}

process.on('SIGINT', () => cleanup(0));
process.on('SIGTERM', () => cleanup(0));
process.on('exit', () => { /* children handled above */ });

main().catch((err) => {
  console.error('  ' + c.red('启动失败：') + err.message);
  cleanup(1);
});
