'use strict';
/**
 * Read-only view of the desktop DSH store: workspaces and persisted session logs.
 * The ACP profile keeps the same on-disk format, so the phone can show what the
 * desktop app already has without touching the running app.
 */
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const zlib = require('node:zlib');

const MAGIC = Buffer.from([0x28, 0xb5, 0x2f, 0xfd]);

function home() {
  return process.env.DSH_HOME || path.join(os.homedir(), '.dsh');
}

function readJson(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return null; }
}

function workspaces() {
  const j = readJson(path.join(home(), 'storages', 'workspace.json'));
  const table = (j && j.tables && j.tables.workspaces) || {};
  const order = (j && j.global && j.global.workspaceIds) || Object.keys(table);
  return order.filter((id) => table[id]).map((id) => ({
    id,
    title: table[id].title || path.basename(table[id].path || ''),
    path: table[id].path,
    sessionIds: table[id].sessionIds || [],
    updatedAt: table[id].updatedAt || table[id].createdAt || null,
  }));
}

function frames(buffer) {
  const cuts = [];
  let i = 0;
  while ((i = buffer.indexOf(MAGIC, i)) >= 0) { cuts.push(i); i += 4; }
  const out = [];
  for (let k = 0; k < cuts.length; k += 1) {
    const end = k + 1 < cuts.length ? cuts[k + 1] : buffer.length;
    try { out.push(zlib.zstdDecompressSync(buffer.subarray(cuts[k], end)).toString('utf8')); }
    catch { /* skip a corrupt frame rather than losing the file */ }
  }
  return out;
}

let cache = { at: 0, index: null };
const peekCache = new Map();

function index() {
  if (cache.index && Date.now() - cache.at < 5000) return cache.index;
  const map = new Map();
  const root = path.join(home(), 'sessions');
  let dirs = [];
  try { dirs = fs.readdirSync(root); } catch { /* no store yet */ }
  for (const dir of dirs) {
    const wsDir = path.join(root, dir);
    let subs = [];
    try { subs = fs.readdirSync(wsDir); } catch { continue; }
    for (const sub of subs) {
      const file = path.join(wsDir, sub, 'session.v4.jsonl.zstd');
      let stat;
      try { stat = fs.statSync(file); } catch { continue; }
      map.set(sub, { id: sub, file, updatedAt: stat.mtimeMs, cwd: '' });
    }
  }
  cache = { at: Date.now(), index: map };
  return map;
}

function peek(file, maxFrames = 10) {
  let stat;
  try { stat = fs.statSync(file); } catch { return { title: '', cwd: '' }; }
  const hit = peekCache.get(file);
  if (hit && hit.mtime === stat.mtimeMs) return hit.meta;
  let buf;
  try { buf = fs.readFileSync(file); } catch { return { title: '', cwd: '' }; }
  const texts = frames(buf).slice(0, maxFrames);
  let title = '';
  let cwd = '';
  for (const text of texts) {
    for (const line of text.split('\n')) {
      if (!line.trim()) continue;
      let rec;
      try { rec = JSON.parse(line); } catch { continue; }
      if (rec.type === 'session' && !cwd) cwd = rec.cwd || '';
      if (rec.type === 'session/title' && rec.data && rec.data.title) title = rec.data.title;
      if (rec.type === 'user/message' && !title && rec.data && rec.data.content) {
        const t = (rec.data.content || []).filter((c) => c.type === 'text').map((c) => c.text).join(' ');
        if (t) title = t.replace(/\s+/g, ' ').slice(0, 22);
      }
      if (title && cwd) {
        const meta = { title, cwd };
        peekCache.set(file, { mtime: stat.mtimeMs, meta });
        return meta;
      }
    }
  }
  const meta = { title, cwd };
  peekCache.set(file, { mtime: stat.mtimeMs, meta });
  return meta;
}

function list() {
  const ws = workspaces();
  const byPath = new Map();
  for (const w of ws) byPath.set(path.resolve(w.path).toLowerCase(), w);
  const items = [];
  for (const [id, info] of index()) {
    let meta = { title: '', cwd: '' };
    try { meta = peek(info.file); } catch { /* ignore */ }
    const cwd = meta.cwd || '';
    const w = byPath.get(path.resolve(cwd || '.').toLowerCase());
    items.push({
      id,
      title: meta.title || '未命名会话',
      cwd,
      workspace: w ? w.title : (cwd ? path.basename(cwd) : ''),
      updatedAt: info.updatedAt,
    });
  }
  items.sort((a, b) => b.updatedAt - a.updatedAt);
  return items;
}

function contentText(content) {
  if (typeof content === 'string') return content;
  if (!Array.isArray(content)) return '';
  return content.map((c) => {
    if (!c) return '';
    if (c.type === 'text') return c.text || '';
    if (c.type === 'reasoning') return '';
    if (c.type === 'image') return '[图片]';
    return '';
  }).filter(Boolean).join('\n');
}

function reasoningText(content) {
  if (!Array.isArray(content)) return '';
  return content.filter((c) => c && c.type === 'reasoning').map((c) => c.text || '').join('\n');
}

function history(sessionId, limit = 260) {
  const info = index().get(sessionId);
  if (!info) return null;
  const items = [];
  const tools = new Map();
  const push = (item) => items.push(item);
  const textItem = (text, kind) => {
    if (!text) return;
    const last = items[items.length - 1];
    if (last && last.kind === kind && !last.sealed) last.text += (last.text ? '\n' : '') + text;
    else push({ id: 'h' + items.length + '-' + kind, kind, text, sealed: true });
  };

  let cwd = '';
  let title = '';
  let buf;
  try { buf = fs.readFileSync(info.file); } catch { return null; }
  for (const chunk of frames(buf)) {
    for (const line of chunk.split('\n')) {
      if (!line.trim()) continue;
      let rec;
      try { rec = JSON.parse(line); } catch { continue; }
      const d = rec.data || {};
      switch (rec.type) {
        case 'session':
          cwd = rec.cwd || cwd;
          break;
        case 'session/title':
          if (d.title) title = d.title;
          break;
        case 'user/message':
        case 'agent/inbox/spliced': {
          const messages = rec.type === 'user/message' ? [d] : (d.inserted || []);
          for (const m of messages) {
            if (m.role !== 'user') continue;
            const text = contentText(m.content);
            if (text) push({ id: 'h' + items.length + '-u', kind: 'user', text });
          }
          break;
        }
        case 'assistant/message': {
          const m = d.message || {};
          const thought = reasoningText(m.content);
          const text = contentText(m.content);
          if (thought) push({ id: 'h' + items.length + '-t', kind: 'thought', text: thought.slice(0, 2000) });
          if (text) textItem(text, 'text');
          break;
        }
        case 'tool/call': {
          const callId = d.callId || '';
          let args = '';
          try {
            const parsed = typeof d.arguments === 'string' ? JSON.parse(d.arguments) : d.arguments;
            args = parsed && (parsed.command || parsed.path || parsed.file_path || parsed.query || '');
            if (!args) args = JSON.stringify(parsed || {});
          } catch { args = String(d.arguments || ''); }
          const item = {
            id: 'h' + items.length + '-c',
            kind: 'tool',
            toolCallId: callId,
            title: args ? `${d.name || 'tool'} · ${String(args).slice(0, 90)}` : (d.name || 'tool'),
            name: d.name || '',
            toolKind: /bash|shell|pwsh|terminal/i.test(d.name || '') ? 'execute' : 'other',
            status: 'completed',
            content: [],
          };
          tools.set(callId, item);
          push(item);
          break;
        }
        case 'tool/result': {
          const item = tools.get(d.toolCallId);
          if (!item) break;
          const text = contentText(d.message && d.message.content);
          item.status = d.isError ? 'failed' : 'completed';
          item.content = [{ type: 'content', content: { type: 'text', text: String(text || '').slice(0, 4000) } }];
          break;
        }
        default:
          break;
      }
    }
  }
  const trimmed = items.slice(-limit);
  return { id: sessionId, cwd, title: title || '未命名会话', updatedAt: info.updatedAt, items: trimmed, total: items.length };
}

module.exports = { home, workspaces, list, history };
