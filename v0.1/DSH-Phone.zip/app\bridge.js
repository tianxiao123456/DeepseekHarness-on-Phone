#!/usr/bin/env node
/**
 * DSH Phone bridge.
 *
 *   phone browser  <--HTTP/WS-->  this bridge  <--ACP (stdio JSON-RPC)-->  dsh --profile acp
 *
 * The bridge owns three things:
 *   1. a tiny HTTP + WebSocket server that serves the mobile UI and a JSON event stream
 *   2. a passcode gate, because the same port is published through a public tunnel
 *   3. an Agent Client Protocol client that drives the real DeepSeek Harness agent
 *
 * No third-party dependencies.
 */
'use strict';

const http = require('node:http');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');
const { StringDecoder } = require('node:string_decoder');
const store = require('./store.js');

const APP_DIR = __dirname;
const WEB_DIR = path.join(APP_DIR, 'web');
const PKG_DIR = path.dirname(APP_DIR);

/* ------------------------------------------------------------------ */
/* arguments                                                           */
/* ------------------------------------------------------------------ */

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i += 1) {
    const a = argv[i];
    if (!a.startsWith('--')) continue;
    const key = a.slice(2);
    const next = argv[i + 1];
    if (next === undefined || next.startsWith('--')) out[key] = true;
    else { out[key] = next; i += 1; }
  }
  return out;
}

const args = parseArgs(process.argv.slice(2));
const DEMO = args.demo === true || process.env.DSH_PHONE_DEMO === '1';
const PORT = Number(args.port || process.env.DSH_PHONE_PORT || 7860);
const HOST = args.host || process.env.DSH_PHONE_HOST || '127.0.0.1';
const PIN = String(args.pin || process.env.DSH_PHONE_PIN || '').replace(/\D/g, '').slice(0, 8);
const PUBLIC_URL = typeof args['public-url'] === 'string' ? args['public-url'] : '';
const DEFAULT_CWD = args.cwd || process.env.DSH_PHONE_CWD || defaultCwd();
const DSH_CLI = args.cli || process.env.DSH_PHONE_CLI || '';

function defaultCwd() {
  const docs = path.join(os.homedir(), 'Documents');
  try { if (fs.statSync(docs).isDirectory()) return docs; } catch { /* ignore */ }
  return os.homedir();
}

if (!DEMO && (!PIN || PIN.length < 6)) {
  console.error('bridge: a 6+ digit --pin is required');
  process.exit(2);
}

/* ------------------------------------------------------------------ */
/* passcode gate                                                       */
/* ------------------------------------------------------------------ */

const COOKIE = 'dshp';
const COOKIE_MAX_AGE = 60 * 60 * 24 * 30;
const sessions = new Map(); // token -> expiry
const attempts = new Map(); // ip -> { count, first, blockedUntil }

function issueToken() {
  const token = crypto.randomBytes(24).toString('base64url');
  sessions.set(token, Date.now() + COOKIE_MAX_AGE * 1000);
  return token;
}

function parseCookies(header) {
  const out = {};
  if (!header) return out;
  for (const part of header.split(';')) {
    const idx = part.indexOf('=');
    if (idx < 0) continue;
    out[part.slice(0, idx).trim()] = decodeURIComponent(part.slice(idx + 1).trim());
  }
  return out;
}

function authorized(req) {
  if (DEMO) return true;
  const token = parseCookies(req.headers.cookie)[COOKIE];
  if (!token) return false;
  const exp = sessions.get(token);
  if (!exp || exp < Date.now()) { sessions.delete(token); return false; }
  return true;
}

function clientIp(req) {
  const fwd = req.headers['cf-connecting-ip'] || req.headers['x-forwarded-for'];
  if (typeof fwd === 'string' && fwd) return fwd.split(',')[0].trim();
  return req.socket.remoteAddress || 'unknown';
}

/* The pairing page reveals the passcode, so it must never be reachable through
 * the tunnel. Cloudflare always adds its own headers; a direct local request
 * carries none of them and addresses the loopback host. */
function isPairRequest(req) {
  if (req.headers['cf-connecting-ip'] || req.headers['x-forwarded-for'] || req.headers['cf-ray']) return false;
  const host = String(req.headers.host || '').replace(/:\d+$/, '').replace(/^\[|\]$/g, '');
  if (!['127.0.0.1', 'localhost', '::1'].includes(host)) return false;
  const ip = req.socket.remoteAddress || '';
  return ip === '127.0.0.1' || ip === '::1' || ip === '::ffff:127.0.0.1';
}

function pinOk(ip, pin) {
  const now = Date.now();
  const rec = attempts.get(ip) || { count: 0, first: now, blockedUntil: 0 };
  if (rec.blockedUntil > now) return false;
  if (now - rec.first > 10 * 60 * 1000) { rec.count = 0; rec.first = now; }
  const a = Buffer.from(String(pin).padEnd(16, ' '));
  const b = Buffer.from(String(PIN).padEnd(16, ' '));
  const ok = a.length === b.length && crypto.timingSafeEqual(a, b) && String(pin) === PIN;
  if (ok) { attempts.delete(ip); return true; }
  rec.count += 1;
  if (rec.count >= 10) { rec.blockedUntil = now + 10 * 60 * 1000; rec.count = 0; rec.first = now; }
  attempts.set(ip, rec);
  return false;
}

function cookieFor(token, req) {
  const secure = PUBLIC_URL.startsWith('https:') || req.headers['x-forwarded-proto'] === 'https';
  return `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${COOKIE_MAX_AGE}${secure ? '; Secure' : ''}`;
}

/* ------------------------------------------------------------------ */
/* ACP client                                                          */
/* ------------------------------------------------------------------ */

class AcpClient {
  constructor(cliPath) {
    this.cliPath = cliPath;
    this.child = null;
    this.nextId = 1;
    this.pending = new Map();
    this.closed = false;
    this.onNotification = () => {};
    this.onRequest = () => {};
    this.onExit = () => {};
    this.stderrTail = [];
  }

  start() {
    const shellCmd = process.platform === 'win32'
      ? `"${this.cliPath}" --profile acp`
      : `'${this.cliPath.replace(/'/g, `'\\''`)}' --profile acp`;
    const child = spawn(shellCmd, {
      shell: true,
      cwd: PKG_DIR,
      env: { ...process.env, DSH_PHONE: '1' },
      stdio: ['pipe', 'pipe', 'pipe'],
      windowsHide: true,
    });
    this.child = child;
    const decoder = new StringDecoder('utf8');
    let buffer = '';
    child.stdout.on('data', (chunk) => {
      buffer += decoder.write(chunk);
      let idx;
      while ((idx = buffer.indexOf('\n')) >= 0) {
        const line = buffer.slice(0, idx).replace(/\r$/, '');
        buffer = buffer.slice(idx + 1);
        if (line.trim()) this._dispatch(line);
      }
      if (buffer.length > 8 * 1024 * 1024) buffer = '';
    });
    child.stderr.on('data', (chunk) => {
      const text = chunk.toString('utf8');
      this.stderrTail.push(text);
      if (this.stderrTail.length > 40) this.stderrTail.shift();
      if (process.env.DSH_PHONE_VERBOSE) process.stderr.write('[acp] ' + text);
    });
    child.on('exit', (code, signal) => {
      this.closed = true;
      for (const [, p] of this.pending) p.reject(new Error(`agent exited (${code ?? signal})`));
      this.pending.clear();
      this.onExit(code, this.stderrTail.join(''));
    });
    child.on('error', (err) => {
      this.closed = true;
      this.onExit(-1, err.message);
    });
  }

  _dispatch(line) {
    let msg;
    try { msg = JSON.parse(line); } catch { return; }
    if (msg.id !== undefined && (msg.result !== undefined || msg.error !== undefined)) {
      const pending = this.pending.get(msg.id);
      if (!pending) return;
      this.pending.delete(msg.id);
      if (msg.error) pending.reject(Object.assign(new Error(msg.error.message || 'agent error'), { rpc: msg.error }));
      else pending.resolve(msg.result);
      return;
    }
    if (msg.method && msg.id !== undefined) {
      Promise.resolve()
        .then(() => this.onRequest(msg.method, msg.params || {}))
        .then((result) => this._write({ jsonrpc: '2.0', id: msg.id, result: result ?? {} }))
        .catch((err) => this._write({ jsonrpc: '2.0', id: msg.id, error: { code: -32603, message: err.message } }));
      return;
    }
    if (msg.method) this.onNotification(msg.method, msg.params || {});
  }

  _write(obj) {
    if (!this.child || this.closed) return false;
    try { this.child.stdin.write(JSON.stringify(obj) + '\n'); return true; }
    catch { return false; }
  }

  request(method, params, timeoutMs = 120000) {
    if (this.closed) return Promise.reject(new Error('agent is not running'));
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`${method} timed out`));
      }, timeoutMs);
      this.pending.set(id, {
        resolve: (v) => { clearTimeout(timer); resolve(v); },
        reject: (e) => { clearTimeout(timer); reject(e); },
      });
      this._write({ jsonrpc: '2.0', id, method, params });
    });
  }

  notify(method, params) { this._write({ jsonrpc: '2.0', method, params }); }

  stop() {
    if (!this.child) return;
    const pid = this.child.pid;
    try {
      if (process.platform === 'win32') spawn('taskkill', ['/pid', String(pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true });
      else this.child.kill('SIGTERM');
    } catch { /* ignore */ }
    setTimeout(() => { try { this.child.kill(); } catch { /* ignore */ } }, 1500).unref();
  }
}

/* ------------------------------------------------------------------ */
/* session state                                                       */
/* ------------------------------------------------------------------ */

const state = {
  sessions: new Map(), // sessionId -> session record
  activeId: null,
  ready: false,
  agentInfo: null,
  demo: DEMO,
};

function newRecord(id, cwd, title) {
  return {
    id,
    cwd,
    title: title || '新会话',
    items: [],
    tools: new Map(),
    configOptions: [],
    plan: null,
    usage: null,
    running: false,
    stopReason: null,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
}

function itemId() { return 'i' + crypto.randomBytes(5).toString('hex'); }

function pushItem(rec, item) {
  rec.items.push(item);
  rec.updatedAt = Date.now();
  if (rec.items.length > 800) rec.items.splice(0, rec.items.length - 800);
  broadcast({ t: 'item', item });
  return item;
}

function appendText(rec, text, kind) {
  const last = rec.items[rec.items.length - 1];
  if (last && last.kind === kind && !last.sealed) {
    last.text += text;
    broadcast({ t: 'patch', id: last.id, text: last.text });
    return last;
  }
  return pushItem(rec, { id: itemId(), kind, text, ts: Date.now() });
}

function sealLast(rec) {
  const last = rec.items[rec.items.length - 1];
  if (last && (last.kind === 'text' || last.kind === 'thought')) last.sealed = true;
}

function touch(rec) { rec.updatedAt = Date.now(); }

function view(rec) {
  return {
    id: rec.id,
    cwd: rec.cwd,
    title: rec.title,
    running: rec.running,
    stopReason: rec.stopReason,
    configOptions: rec.configOptions,
    usage: rec.usage,
    plan: rec.plan,
    items: rec.items,
    updatedAt: rec.updatedAt,
  };
}

function currentRecord() { return state.activeId ? state.sessions.get(state.activeId) : null; }

function handleUpdate(params) {
  const rec = state.sessions.get(params.sessionId);
  if (!rec) return;
  const u = params.update || {};
  touch(rec);
  switch (u.sessionUpdate) {
    case 'agent_message_chunk': {
      const text = u.content && u.content.type === 'text' ? u.content.text : '';
      if (text) appendText(rec, text, 'text');
      break;
    }
    case 'agent_thought_chunk': {
      const text = u.content && u.content.type === 'text' ? u.content.text : '';
      if (text) appendText(rec, text, 'thought');
      break;
    }
    case 'user_message_chunk': {
      const text = u.content && u.content.type === 'text' ? u.content.text : '';
      if (text) appendText(rec, text, 'user');
      break;
    }
    case 'tool_call': {
      sealLast(rec);
      const item = {
        id: itemId(),
        kind: 'tool',
        toolCallId: u.toolCallId,
        title: u.title || u.name || '工具调用',
        name: u.name || '',
        toolKind: u.kind || 'other',
        status: u.status || 'pending',
        content: u.content || [],
        rawInput: u.rawInput,
        rawOutput: u.rawOutput,
        ts: Date.now(),
      };
      rec.tools.set(u.toolCallId, item);
      pushItem(rec, item);
      break;
    }
    case 'tool_call_update': {
      const item = rec.tools.get(u.toolCallId);
      if (!item) break;
      if (u.title) item.title = u.title;
      if (u.status) item.status = u.status;
      if (u.kind) item.toolKind = u.kind;
      if (u.content) item.content = u.content;
      if (u.rawInput !== undefined) item.rawInput = u.rawInput;
      if (u.rawOutput !== undefined) item.rawOutput = u.rawOutput;
      broadcast({ t: 'tool', id: item.id, patch: {
        title: item.title, status: item.status, content: item.content,
        rawInput: item.rawInput, rawOutput: item.rawOutput, toolKind: item.toolKind,
      } });
      break;
    }
    case 'plan': {
      rec.plan = { entries: u.entries || [], ts: Date.now() };
      broadcast({ t: 'plan', plan: rec.plan });
      break;
    }
    case 'plan_update': {
      rec.plan = { entries: u.entries || [], ts: Date.now() };
      broadcast({ t: 'plan', plan: rec.plan });
      break;
    }
    case 'plan_removed': {
      rec.plan = null;
      broadcast({ t: 'plan', plan: null });
      break;
    }
    case 'config_option_update': {
      if (Array.isArray(u.configOptions)) {
        rec.configOptions = u.configOptions;
        broadcast({ t: 'config', configOptions: rec.configOptions });
      }
      break;
    }
    case 'usage_update': {
      rec.usage = { used: u.used, size: u.size, cost: u.cost || null };
      broadcast({ t: 'usage', usage: rec.usage });
      break;
    }
    case 'session_info_update': {
      if (u.title) { rec.title = u.title; broadcast({ t: 'title', title: rec.title }); }
      break;
    }
    default:
      break;
  }
}

async function handlePermission(params) {
  const rec = state.sessions.get(params.sessionId);
  const reqId = 'p' + crypto.randomBytes(6).toString('hex');
  const request = {
    reqId,
    sessionId: params.sessionId,
    toolCall: params.toolCall || {},
    options: params.options || [],
  };
  broadcast({ t: 'permission', request });
  const answer = await new Promise((resolve) => {
    permissionWaiters.set(reqId, resolve);
    setTimeout(() => {
      if (permissionWaiters.delete(reqId)) resolve(null);
    }, 5 * 60 * 1000);
  });
  if (!answer) return { outcome: { outcome: 'cancelled' } };
  return { outcome: { outcome: 'selected', optionId: answer } };
}

const permissionWaiters = new Map();

/* ------------------------------------------------------------------ */
/* websocket fan-out                                                   */
/* ------------------------------------------------------------------ */

const clients = new Set();

function broadcast(msg) {
  const data = JSON.stringify(msg);
  for (const ws of clients) ws.send(data);
}

/* ------------------------------------------------------------------ */
/* ACP orchestration                                                   */
/* ------------------------------------------------------------------ */

let acp = null;
let shuttingDown = false;
let restarts = 0;

async function bootAgent() {
  acp = new AcpClient(DSH_CLI);
  acp.onNotification = (method, params) => {
    if (method === 'session/update') handleUpdate(params);
  };
  acp.onRequest = async (method, params) => {
    if (method === 'session/request_permission') return handlePermission(params);
    return {};
  };
  acp.onExit = (code, stderr) => {
    state.ready = false;
    for (const rec of state.sessions.values()) {
      if (rec.running) { rec.running = false; broadcast({ t: 'status', running: false, stopReason: 'error' }); }
    }
    broadcast({ t: 'agent', connected: false, message: `agent 已退出 (${code})`, detail: String(stderr || '').slice(-800) });
    if (!shuttingDown && restarts < 3) {
      restarts += 1;
      console.error(`[agent] restarting (${restarts}/3)…`);
      setTimeout(() => bootAgent().then(() => { restarts = 0; }).catch((err) => console.error('[agent] restart failed:', err.message)), 2500);
    }
  };
  acp.start();
  const init = await acp.request('initialize', {
    protocolVersion: 1,
    clientCapabilities: { fs: { readTextFile: false, writeTextFile: false } },
    clientInfo: { name: 'dsh-phone', version: '1.0.0' },
  }, 60000);
  state.agentInfo = init && init.agentInfo ? init.agentInfo : null;
  state.ready = true;
  broadcast({ t: 'agent', connected: true, info: state.agentInfo });
}

async function listSessions(cwd) {
  const params = {};
  if (cwd) params.cwd = cwd;
  const res = await acp.request('session/list', params, 30000);
  return (res && res.sessions) || [];
}

/* Model options arrive as a two-level tree; a value is a JSON route tuple such
 * as ["deepseek-account","deepseek-flash"]. The shipped ACP profile defaults to
 * the API-key route, while a desktop login authenticates the account route, so
 * pick a route that can actually answer. */
function flattenOptions(option) {
  const out = [];
  const walk = (items, group) => {
    for (const item of items || []) {
      if (Array.isArray(item.options)) walk(item.options, item.group || item.name || group);
      else out.push({ value: item.value, name: item.name, description: item.description || '', group: item.group || group || '' });
    }
  };
  walk(option && option.options);
  return out;
}

function routeOf(value) {
  try {
    const arr = JSON.parse(String(value));
    if (Array.isArray(arr) && arr.length) return String(arr[0]);
  } catch { /* not a route tuple */ }
  return '';
}

function modelIdOf(value) {
  try {
    const arr = JSON.parse(String(value));
    if (Array.isArray(arr) && arr.length > 1) return String(arr[1]);
  } catch { /* ignore */ }
  return String(value || '');
}

async function ensureUsableModel(rec) {
  const opt = rec.configOptions.find((o) => o.id === 'model' || o.category === 'model');
  if (!opt) return;
  const route = routeOf(opt.currentValue);
  if (route !== 'deepseek-official') return;
  if (process.env.DEEPSEEK_API_KEY) return;
  const flat = flattenOptions(opt);
  const account = flat.filter((o) => routeOf(o.value) === 'deepseek-account');
  if (!account.length) return;
  const wantsPro = /pro/i.test(modelIdOf(opt.currentValue));
  const choice = account.find((o) => (wantsPro ? /pro/i.test(o.name) : /flash/i.test(o.name))) || account[0];
  try {
    const res = await acp.request('session/set_config_option', { sessionId: rec.id, configId: opt.id, value: choice.value }, 60000);
    if (res && Array.isArray(res.configOptions)) rec.configOptions = res.configOptions;
    console.log(`[model] ${route} has no key; switched to ${choice.name}`);
  } catch (err) {
    console.error('[model] switch failed:', err.message);
  }
}

async function newSession(cwd) {
  const res = await acp.request('session/new', { cwd, mcpServers: [] }, 120000);
  const rec = newRecord(res.sessionId, cwd);
  rec.configOptions = res.configOptions || [];
  await ensureUsableModel(rec);
  state.sessions.set(rec.id, rec);
  state.activeId = rec.id;
  broadcast({ t: 'session', session: view(rec) });
  return rec;
}

async function resumeSession(sessionId, cwd, title) {
  const res = await acp.request('session/resume', { sessionId, cwd, mcpServers: [] }, 120000);
  let rec = state.sessions.get(sessionId);
  if (!rec) {
    rec = newRecord(sessionId, cwd, title);
    state.sessions.set(sessionId, rec);
  }
  rec.configOptions = (res && res.configOptions) || rec.configOptions;
  await ensureUsableModel(rec);
  state.activeId = sessionId;
  broadcast({ t: 'session', session: view(rec), resumed: true });
  return rec;
}

async function prompt(text) {
  const rec = currentRecord();
  if (!rec) throw new Error('没有打开的会话');
  if (rec.running) throw new Error('上一条消息还在处理中');
  if (!rec.items.length && (!rec.title || rec.title === '新会话')) {
    rec.title = text.replace(/\s+/g, ' ').slice(0, 18) + (text.length > 18 ? '…' : '');
    broadcast({ t: 'title', title: rec.title });
  }
  sealLast(rec);
  pushItem(rec, { id: itemId(), kind: 'user', text, ts: Date.now() });
  rec.running = true;
  rec.stopReason = null;
  broadcast({ t: 'status', running: true });
  try {
    const res = await acp.request('session/prompt', {
      sessionId: rec.id,
      prompt: [{ type: 'text', text }],
    }, 24 * 60 * 60 * 1000);
    rec.stopReason = res && res.stopReason;
    if (res && res.usage) { rec.usage = { used: res.usage.totalTokens, size: rec.usage ? rec.usage.size : 0, cost: res.usage.cost || null }; }
  } finally {
    rec.running = false;
    sealLast(rec);
    broadcast({ t: 'status', running: false, stopReason: rec.stopReason });
  }
}

function cancelPrompt() {
  const rec = currentRecord();
  if (!rec || !rec.running) return;
  acp.notify('session/cancel', { sessionId: rec.id });
}

async function setConfig(configId, value, isBoolean) {
  const rec = currentRecord();
  if (!rec) throw new Error('没有打开的会话');
  const params = { sessionId: rec.id, configId, value };
  if (isBoolean) params.type = 'boolean';
  const res = await acp.request('session/set_config_option', params, 60000);
  if (res && Array.isArray(res.configOptions)) {
    rec.configOptions = res.configOptions;
    broadcast({ t: 'config', configOptions: rec.configOptions });
  }
}

/* ------------------------------------------------------------------ */
/* demo agent                                                          */
/* ------------------------------------------------------------------ */

function startDemo() {
  state.ready = true;
  const demos = [
    { id: 'demo-1', cwd: DEFAULT_CWD, title: '整理下载文件夹' },
    { id: 'demo-2', cwd: DEFAULT_CWD, title: '给 README 补一段安装说明' },
    { id: 'demo-3', cwd: DEFAULT_CWD, title: '检查昨天的构建日志' },
  ];
  for (const d of demos) {
    const rec = newRecord(d.id, d.cwd, d.title);
    rec.updatedAt = Date.now() - Math.random() * 86400000;
    state.sessions.set(d.id, rec);
  }
  const rec = state.sessions.get('demo-1');
  state.activeId = rec.id;
  rec.configOptions = [
    {
      id: 'model', name: '模型', category: 'model', type: 'select', currentValue: 'deepseek-v4-flash',
      options: [
        { value: 'deepseek-v4-flash', name: 'DeepSeek V4 Flash', description: '响应快，适合日常任务' },
        { value: 'deepseek-v4-pro', name: 'DeepSeek V4 Pro', description: '更强的推理与代码能力' },
      ],
    },
    {
      id: 'reasoning_effort', name: '推理强度', category: 'thought_level', type: 'select', currentValue: 'medium',
      options: [
        { value: 'low', name: '低' }, { value: 'medium', name: '中' }, { value: 'high', name: '高' },
      ],
    },
  ];
  rec.usage = { used: 18420, size: 200000, cost: null };
  pushItem(rec, { id: itemId(), kind: 'user', text: '帮我把下载文件夹里这周的文件按类型归档，别动安装包。', ts: Date.now() - 60000 });
  pushItem(rec, {
    id: itemId(), kind: 'tool', toolCallId: 'demo-tool-1', title: '列出 下载 目录（最近 7 天）',
    name: 'bash', toolKind: 'execute', status: 'completed', ts: Date.now() - 55000,
    content: [{ type: 'content', content: { type: 'text', text: '12 个文件\n8 个可归档\n4 个安装包（跳过）' } }],
  });
  pushItem(rec, {
    id: itemId(), kind: 'text', ts: Date.now() - 50000,
    text: '我先扫了一遍 **下载** 目录：本周新增 12 个文件，其中 4 个是安装包（已跳过），其余 8 个可以归档。\n\n计划如下：\n\n1. 文档 → `文档/收件箱`\n2. 图片 → `图片/本周`\n3. 压缩包 → `归档/压缩包`\n\n开始执行前想确认一下：**同名的旧文件要怎么处理？**',
  });
  rec.running = false;
}

async function demoPrompt(text) {
  const rec = currentRecord();
  if (!rec) return;
  pushItem(rec, { id: itemId(), kind: 'user', text, ts: Date.now() });
  rec.running = true;
  broadcast({ t: 'status', running: true });
  const steps = [
    { kind: 'thought', text: '先理解用户意图，再决定是否需要工具。' },
    { kind: 'tool', title: '读取 下载 目录', status: 'in_progress' },
  ];
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  try {
    for (const s of steps) {
      await wait(400);
      if (s.kind === 'thought') appendText(rec, s.text, 'thought');
      else {
        const item = {
          id: itemId(), kind: 'tool', toolCallId: 'demo-' + Date.now(), title: s.title,
          name: 'bash', toolKind: 'read', status: s.status, content: [], ts: Date.now(),
        };
        rec.tools.set(item.toolCallId, item);
        pushItem(rec, item);
        await wait(900);
        item.status = 'completed';
        item.content = [{ type: 'content', content: { type: 'text', text: '共 12 项' } }];
        broadcast({ t: 'tool', id: item.id, patch: { status: item.status, content: item.content } });
      }
    }
    const answer = `收到。这是 **演示模式** 的回复，用来预览手机端界面。\n\n真正运行时，这里的每一段文字都来自电脑上的 DeepSeek Harness：它会读取文件、执行命令、修改代码，并在敏感操作前弹确认。\n\n\`\`\`js\nconst phone = await dsh.connect({ pin: '427193' });\nphone.on('tool', renderToolCard);\n\`\`\`\n\n想结束演示？在电脑上关掉启动窗口即可。`;
    const chunkSize = 12;
    for (let i = 0; i < answer.length; i += chunkSize) {
      appendText(rec, answer.slice(i, i + chunkSize), 'text');
      await wait(35);
    }
    rec.stopReason = 'end_turn';
  } finally {
    rec.running = false;
    sealLast(rec);
    broadcast({ t: 'status', running: false, stopReason: rec.stopReason });
  }
}

/* ------------------------------------------------------------------ */
/* http helpers                                                        */
/* ------------------------------------------------------------------ */

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
};

function send(res, status, body, headers) {
  res.writeHead(status, Object.assign({ 'Cache-Control': 'no-store' }, headers || {}));
  res.end(body);
}

function sendJson(res, status, obj) {
  send(res, status, JSON.stringify(obj), { 'Content-Type': 'application/json; charset=utf-8' });
}

function readBody(req, limit = 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new Error('body too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

async function serveFile(res, file, extraHeaders) {
  try {
    const data = await fsp.readFile(file);
    const ext = path.extname(file).toLowerCase();
    send(res, 200, data, Object.assign({
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Cache-Control': ext === '.html' ? 'no-store' : 'public, max-age=86400',
    }, extraHeaders || {}));
  } catch {
    send(res, 404, 'not found');
  }
}

/* ------------------------------------------------------------------ */
/* HTTP server                                                         */
/* ------------------------------------------------------------------ */

const loginPage = `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
<meta name="theme-color" content="#0b0d12" />
<title>DSH Phone · 解锁</title>
<style>
  :root { color-scheme: dark; }
  * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
  body { margin: 0; min-height: 100dvh; display: grid; place-items: center; background:
    radial-gradient(120% 80% at 50% 0%, #17203a 0%, #0b0d12 55%, #07080c 100%);
    color: #eef1f7; font: 16px/1.5 -apple-system, "SF Pro Text", "PingFang SC", "Microsoft YaHei", system-ui, sans-serif;
    padding: calc(env(safe-area-inset-top) + 24px) 24px calc(env(safe-area-inset-bottom) + 24px); }
  .card { width: 100%; max-width: 360px; text-align: center; }
  .mark { width: 64px; height: 64px; margin: 0 auto 18px; border-radius: 18px;
    background: linear-gradient(160deg, #4d6bfe, #2b3fd1); display: grid; place-items: center;
    box-shadow: 0 12px 40px rgba(77,107,254,.35); font-size: 34px; }
  h1 { font-size: 22px; margin: 0 0 6px; letter-spacing: .2px; }
  p { color: #9aa4b8; margin: 0 0 26px; font-size: 14px; }
  input { width: 100%; text-align: center; letter-spacing: 12px; text-indent: 12px;
    font-size: 28px; font-variant-numeric: tabular-nums; padding: 16px 10px; border-radius: 16px;
    border: 1px solid rgba(255,255,255,.12); background: rgba(255,255,255,.05); color: #fff; outline: none; }
  input:focus { border-color: rgba(77,107,254,.8); box-shadow: 0 0 0 4px rgba(77,107,254,.15); }
  button { margin-top: 16px; width: 100%; padding: 16px; border-radius: 16px; border: 0;
    background: linear-gradient(180deg, #5a76ff, #3f59f0); color: #fff; font-size: 17px; font-weight: 600; }
  button:active { transform: scale(.985); }
  .err { color: #ff8f8f; font-size: 13px; min-height: 20px; margin-top: 12px; }
  .hint { margin-top: 22px; font-size: 12px; color: #6f7a90; }
</style></head>
<body><div class="card">
  <div class="mark">🐋</div>
  <h1>连接你的电脑</h1>
  <p>输入电脑上显示的 6 位访问码</p>
  <form id="f">
    <input id="pin" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="••••••" autofocus />
    <button type="submit">进入 DSH</button>
  </form>
  <div class="err" id="err"></div>
  <div class="hint">访问码只在本机启动窗口里显示<br/>离开时可直接关闭窗口断开</div>
</div>
<script>
  const f = document.getElementById('f');
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const pin = document.getElementById('pin').value.trim();
    const err = document.getElementById('err');
    err.textContent = '';
    const r = await fetch('/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pin }) });
    if (r.ok) location.replace('/');
    else { err.textContent = '访问码不正确，或尝试次数过多'; }
  });
</script></body></html>`;

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const pathname = decodeURIComponent(url.pathname);

  if (pathname === '/healthz') return sendJson(res, 200, { ok: true, demo: DEMO });

  if (pathname === '/pair' || pathname === '/pair/info') {
    if (!DEMO && !isPairRequest(req)) {
      return send(res, 403, 'pairing page is local only');
    }
    if (pathname === '/pair/info') {
      const port = server.address() && server.address().port;
      return sendJson(res, 200, {
        url: PUBLIC_URL || `http://127.0.0.1:${port}`,
        pin: PIN || '------',
        tunnel: /^https?:/.test(PUBLIC_URL) && !/^http:\/\/(127\.|localhost|192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/.test(PUBLIC_URL),
      });
    }
    return serveFile(res, path.join(WEB_DIR, 'pair.html'), { 'Content-Type': 'text/html; charset=utf-8' });
  }

  if (pathname === '/login' && req.method === 'POST') {
    let pin = '';
    try { pin = JSON.parse(await readBody(req)).pin || ''; } catch { /* ignore */ }
    const ip = clientIp(req);
    if (!pinOk(ip, String(pin))) return sendJson(res, 401, { error: 'invalid pin' });
    const token = issueToken();
    return sendJson(res, 200, { ok: true }, { 'Set-Cookie': cookieFor(token, req) });
  }

  // ?k=PIN one-shot entry used by the QR code
  if (url.searchParams.has('k')) {
    const ip = clientIp(req);
    if (pinOk(ip, url.searchParams.get('k') || '')) {
      const token = issueToken();
      url.searchParams.delete('k');
      const target = url.pathname + (url.search || '');
      return send(res, 303, '', { Location: target || '/', 'Set-Cookie': cookieFor(token, req) });
    }
    return send(res, 401, 'bad passcode');
  }

  // Public static assets: they carry no session data, and the login/pair pages
  // need them before a cookie exists.
  if (['/app.css', '/app.js', '/qrcode.js', '/icon.svg', '/manifest.webmanifest'].includes(pathname)) {
    return serveFile(res, path.join(WEB_DIR, pathname.slice(1)));
  }

  if (!authorized(req)) {
    if (pathname === '/api/state') return sendJson(res, 401, { error: 'unauthorized' });
    return send(res, 200, loginPage, { 'Content-Type': 'text/html; charset=utf-8' });
  }

  if (pathname === '/' || pathname === '/index.html') {
    return serveFile(res, path.join(WEB_DIR, 'index.html'));
  }

  if (pathname === '/api/state') {
    const rec = currentRecord();
    return sendJson(res, 200, {
      demo: DEMO,
      ready: state.ready,
      agent: state.agentInfo,
      publicUrl: PUBLIC_URL,
      session: rec ? view(rec) : null,
      sessions: [...state.sessions.values()].map((r) => ({ id: r.id, title: r.title, cwd: r.cwd, updatedAt: r.updatedAt })),
    });
  }

  if (pathname.startsWith('/api/')) {
    return sendJson(res, 404, { error: 'not found' });
  }

  // static assets only from web/
  const rel = pathname.replace(/^\/+/, '');
  const file = path.join(WEB_DIR, rel);
  if (!file.startsWith(WEB_DIR + path.sep)) return send(res, 403, 'forbidden');
  return serveFile(res, file);
});

/* ------------------------------------------------------------------ */
/* websocket                                                           */
/* ------------------------------------------------------------------ */

const WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

server.on('upgrade', (req, socket) => {
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname !== '/ws') { socket.destroy(); return; }
  const keyOk = url.searchParams.has('k') ? pinOk(clientIp(req), url.searchParams.get('k')) : authorized(req);
  if (!keyOk) {
    socket.write('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n');
    socket.destroy();
    return;
  }
  const key = req.headers['sec-websocket-key'];
  if (!key) { socket.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + WS_GUID).digest('base64');
  socket.write([
    'HTTP/1.1 101 Switching Protocols',
    'Upgrade: websocket',
    'Connection: Upgrade',
    `Sec-WebSocket-Accept: ${accept}`,
    '\r\n',
  ].join('\r\n'));

  const client = makeClient(socket);
  clients.add(client);
  const rec = currentRecord();
  client.send(JSON.stringify({ t: 'hello', demo: DEMO, ready: state.ready, agent: state.agentInfo, session: rec ? view(rec) : null }));
});

function makeClient(socket) {
  let buffer = Buffer.alloc(0);
  let fragments = [];
  let closed = false;

  const client = {
    send(text) {
      if (closed) return;
      const payload = Buffer.from(text, 'utf8');
      let header;
      if (payload.length < 126) {
        header = Buffer.from([0x81, payload.length]);
      } else if (payload.length < 65536) {
        header = Buffer.alloc(4);
        header[0] = 0x81; header[1] = 126; header.writeUInt16BE(payload.length, 2);
      } else {
        header = Buffer.alloc(10);
        header[0] = 0x81; header[1] = 127; header.writeBigUInt64BE(BigInt(payload.length), 2);
      }
      try { socket.write(Buffer.concat([header, payload])); } catch { /* ignore */ }
    },
    close() {
      if (closed) return;
      closed = true;
      clients.delete(client);
      try { socket.end(); } catch { /* ignore */ }
    },
  };

  socket.setNoDelay(true);
  socket.on('data', (chunk) => {
    buffer = Buffer.concat([buffer, chunk]);
    for (;;) {
      if (buffer.length < 2) return;
      const fin = (buffer[0] & 0x80) !== 0;
      const opcode = buffer[0] & 0x0f;
      const masked = (buffer[1] & 0x80) !== 0;
      let len = buffer[1] & 0x7f;
      let offset = 2;
      if (len === 126) {
        if (buffer.length < 4) return;
        len = buffer.readUInt16BE(2); offset = 4;
      } else if (len === 127) {
        if (buffer.length < 10) return;
        len = Number(buffer.readBigUInt64BE(2)); offset = 10;
      }
      const maskLen = masked ? 4 : 0;
      if (buffer.length < offset + maskLen + len) return;
      const mask = masked ? buffer.slice(offset, offset + 4) : null;
      offset += maskLen;
      const payload = Buffer.from(buffer.slice(offset, offset + len));
      if (mask) for (let i = 0; i < payload.length; i += 1) payload[i] ^= mask[i % 4];
      buffer = buffer.slice(offset + len);

      if (opcode === 0x8) { client.close(); return; }
      if (opcode === 0x9) { // ping
        try { socket.write(Buffer.from([0x8a, payload.length])); } catch { /* ignore */ }
        continue;
      }
      if (opcode === 0x0a) continue; // pong
      if (opcode === 0x0 || opcode === 0x1 || opcode === 0x2) {
        fragments.push(payload);
        if (!fin) continue;
        const data = Buffer.concat(fragments).toString('utf8');
        fragments = [];
        if (opcode === 0x1 || opcode === 0x0) handleCommand(client, data);
      }
    }
  });
  socket.on('close', () => client.close());
  socket.on('error', () => client.close());
  return client;
}

async function handleCommand(client, raw) {
  let msg;
  try { msg = JSON.parse(raw); } catch { return; }
  const respond = (obj) => client.send(JSON.stringify(obj));
  try {
    switch (msg.op) {
      case 'ping':
        respond({ t: 'pong' });
        break;
      case 'attach': {
        if (msg.sessionId && state.sessions.has(msg.sessionId)) state.activeId = msg.sessionId;
        const rec = currentRecord();
        respond({ t: 'snapshot', session: rec ? view(rec) : null });
        break;
      }
      case 'sessions': {
        if (DEMO) {
          respond({ t: 'sessions', sessions: [...state.sessions.values()].map((r) => ({ id: r.id, title: r.title, cwd: r.cwd, updatedAt: r.updatedAt })) });
        } else {
          const merged = new Map();
          for (const s of store.list()) merged.set(s.id, s);
          try {
            const live = await listSessions(msg.cwd);
            for (const s of live) {
              const prev = merged.get(s.sessionId) || {};
              merged.set(s.sessionId, {
                id: s.sessionId,
                title: s.title || prev.title || '未命名会话',
                cwd: s.cwd || prev.cwd || '',
                workspace: prev.workspace || '',
                updatedAt: prev.updatedAt || (s.updatedAt ? Date.parse(s.updatedAt) : Date.now()),
              });
            }
          } catch { /* ACP may be busy; the on-disk index still answers */ }
          const sessions = [...merged.values()].sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0)).slice(0, 80);
          respond({ t: 'sessions', sessions });
        }
        break;
      }
      case 'workspaces':
        respond({ t: 'workspaces', workspaces: DEMO ? [] : store.workspaces() });
        break;
      case 'history': {
        const h = DEMO ? null : store.history(msg.sessionId);
        if (!h) { respond({ t: 'error', message: '找不到这条会话记录' }); break; }
        respond({ t: 'history', session: h });
        break;
      }
      case 'new': {
        const cwd = msg.cwd || DEFAULT_CWD;
        const rec = DEMO ? (() => { const r = newRecord('demo-' + Date.now(), cwd, '新会话'); state.sessions.set(r.id, r); state.activeId = r.id; return r; })() : await newSession(cwd);
        respond({ t: 'session', session: view(rec) });
        break;
      }
      case 'resume': {
        const rec = DEMO
          ? state.sessions.get(msg.sessionId)
          : await resumeSession(msg.sessionId, msg.cwd || DEFAULT_CWD, msg.title);
        if (rec) { state.activeId = rec.id; respond({ t: 'snapshot', session: view(rec), resumed: true }); }
        else respond({ t: 'error', message: '会话不存在' });
        break;
      }
      case 'prompt': {
        const text = String(msg.text || '').trim();
        if (!text) return;
        if (DEMO) demoPrompt(text);
        else prompt(text).catch((err) => {
          const rec = currentRecord();
          if (rec) { rec.running = false; rec.items.push({ id: itemId(), kind: 'error', text: err.message, ts: Date.now() }); }
          respond({ t: 'error', message: err.message });
          broadcast({ t: 'status', running: false, stopReason: 'error' });
        });
        break;
      }
      case 'cancel':
        if (!DEMO) cancelPrompt();
        break;
      case 'permission': {
        const waiter = permissionWaiters.get(msg.reqId);
        if (waiter) { permissionWaiters.delete(msg.reqId); waiter(msg.optionId || null); }
        break;
      }
      case 'config':
        if (!DEMO) await setConfig(msg.configId, msg.value, !!msg.boolean);
        else {
          const rec = currentRecord();
          if (rec) {
            const opt = rec.configOptions.find((o) => o.id === msg.configId);
            if (opt) opt.currentValue = msg.value;
            respond({ t: 'config', configOptions: rec.configOptions });
          }
        }
        break;
      case 'close': {
        if (DEMO) respond({ t: 'closed', sessionId: msg.sessionId });
        else {
          await acp.request('session/close', { sessionId: msg.sessionId }, 60000);
          respond({ t: 'closed', sessionId: msg.sessionId });
        }
        break;
      }
      default:
        respond({ t: 'error', message: 'unknown op' });
    }
  } catch (err) {
    respond({ t: 'error', message: err.message });
  }
}

/* ------------------------------------------------------------------ */
/* boot                                                                */
/* ------------------------------------------------------------------ */

async function main() {
  await new Promise((resolve) => server.listen(PORT, HOST, resolve));
  const addr = server.address();
  const port = typeof addr === 'object' && addr ? addr.port : PORT;
  console.log('');
  console.log('  DSH Phone bridge');
  console.log(`  local   http://127.0.0.1:${port}/?k=${PIN || 'demo'}`);
  if (PUBLIC_URL) console.log(`  public  ${PUBLIC_URL}/?k=${PIN}`);
  console.log(`  mode    ${DEMO ? 'demo' : 'live'} · cwd ${DEFAULT_CWD}`);
  console.log('');
  if (DEMO) startDemo();
  else {
    try { await bootAgent(); }
    catch (err) {
      console.error('  agent failed to start:', err.message);
      if (!state.ready) {
        console.error('  check the DSH installation path (--cli) and try again.');
      }
    }
  }
  // expose the resolved port for the launcher
  process.stdout.write(`DSH_PHONE_PORT=${port}\n`);
}

main().catch((err) => {
  console.error('bridge failed:', err);
  process.exit(1);
});

function shutdown() {
  shuttingDown = true;
  if (acp) acp.stop();
  for (const ws of clients) ws.close();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 800).unref();
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
