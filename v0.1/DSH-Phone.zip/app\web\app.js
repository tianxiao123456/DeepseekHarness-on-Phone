/* DSH Phone — mobile client */

const $ = (sel) => document.querySelector(sel);
const el = (tag, cls, html) => {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (html !== undefined) node.innerHTML = html;
  return node;
};

const state = {
  ws: null,
  connected: false,
  demo: false,
  ready: false,
  sessionId: null,
  title: '',
  cwd: '',
  items: [],
  running: false,
  configOptions: [],
  usage: null,
  plan: null,
  sessions: [],
  workspaces: [],
  readonly: false,
  pendingPermission: null,
  permissionQueue: [],
  retry: 0,
  lastMessageAt: Date.now(),
};

const ui = {
  app: $('#app'),
  scroller: $('#scroller'),
  thread: $('#thread'),
  hero: $('#hero'),
  input: $('#input'),
  send: $('#sendBtn'),
  title: $('#sessionTitle'),
  sub: $('#sessionSub'),
  modelChip: $('#modelChip'),
  modelName: $('#modelName'),
  drawer: $('#drawer'),
  scrim: $('#scrim'),
  sessionList: $('#sessionList'),
  workspaceList: $('#workspaceList'),
  resumeBar: $('#resumeBar'),
  sheetWrap: $('#sheetWrap'),
  sheet: $('#sheet'),
  planStrip: $('#planStrip'),
  planText: $('#planText'),
  planCount: $('#planCount'),
  usage: $('#usage'),
  usageFill: $('#usageFill'),
  usageText: $('#usageText'),
};

const nodeById = new Map();

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

function toast(text) {
  const t = $('#toast');
  t.textContent = text;
  t.hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => { t.hidden = true; }, 2200);
}

function timeAgo(ts) {
  if (!ts) return '';
  const diff = Date.now() - new Date(ts).getTime();
  if (!Number.isFinite(diff) || diff < 0) return '刚刚';
  const min = Math.floor(diff / 60000);
  if (min < 1) return '刚刚';
  if (min < 60) return `${min} 分钟前`;
  const h = Math.floor(min / 60);
  if (h < 24) return `${h} 小时前`;
  const d = Math.floor(h / 24);
  if (d === 1) return '昨天';
  if (d < 7) return `${d} 天前`;
  return new Date(ts).toLocaleDateString('zh-CN', { month: 'numeric', day: 'numeric' });
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/* ------------------------------------------------------------------ */
/* markdown (small, safe subset)                                       */
/* ------------------------------------------------------------------ */

function inlineMd(text) {
  let s = esc(text);
  s = s.replace(/`([^`\n]+)`/g, (_, code) => `<code>${code}</code>`);
  s = s.replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>');
  s = s.replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noreferrer noopener">$1</a>');
  return s;
}

function mdToHtml(src) {
  const blocks = [];
  const text = String(src).replace(/```([\w+-]*)\n?([\s\S]*?)```/g, (_, lang, code) => {
    const i = blocks.length;
    blocks.push({ lang: (lang || '').trim(), code: code.replace(/\n$/, '') });
    return `\u0000BLOCK${i}\u0000`;
  });

  const lines = text.split('\n');
  const html = [];
  let list = null;
  let para = [];

  const flushPara = () => {
    if (!para.length) return;
    html.push(`<p>${inlineMd(para.join('\n')).replace(/\n/g, '<br/>')}</p>`);
    para = [];
  };
  const flushList = () => {
    if (!list) return;
    html.push(`<${list.tag}>${list.items.map((i) => `<li>${inlineMd(i)}</li>`).join('')}</${list.tag}>`);
    list = null;
  };

  for (const raw of lines) {
    const line = raw.replace(/\s+$/, '');
    if (!line.trim()) { flushPara(); flushList(); continue; }
    const block = line.match(/^\u0000BLOCK(\d+)\u0000$/);
    if (block) {
      flushPara(); flushList();
      const b = blocks[Number(block[1])];
      html.push(`<pre><div class="code-head"><span class="code-lang">${esc(b.lang || 'code')}</span><button class="code-copy" data-copy="${esc(b.code)}">复制</button></div><code>${esc(b.code)}</code></pre>`);
      continue;
    }
    const h = line.match(/^(#{1,3})\s+(.*)$/);
    if (h) { flushPara(); flushList(); html.push(`<h${h[1].length}>${inlineMd(h[2])}</h${h[1].length}>`); continue; }
    if (/^([-*_])\1{2,}$/.test(line.trim())) { flushPara(); flushList(); html.push('<hr/>'); continue; }
    const quote = line.match(/^>\s?(.*)$/);
    if (quote) { flushPara(); flushList(); html.push(`<blockquote>${inlineMd(quote[1])}</blockquote>`); continue; }
    const ul = line.match(/^\s*[-*]\s+(.*)$/);
    if (ul) {
      flushPara();
      if (!list || list.tag !== 'ul') { flushList(); list = { tag: 'ul', items: [] }; }
      list.items.push(ul[1]);
      continue;
    }
    const ol = line.match(/^\s*\d+[.)]\s+(.*)$/);
    if (ol) {
      flushPara();
      if (!list || list.tag !== 'ol') { flushList(); list = { tag: 'ol', items: [] }; }
      list.items.push(ol[1]);
      continue;
    }
    flushList();
    para.push(line);
  }
  flushPara();
  flushList();
  return html.join('');
}

/* ------------------------------------------------------------------ */
/* tool card                                                           */
/* ------------------------------------------------------------------ */

const TOOL_ICONS = {
  read: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 5.5A2.5 2.5 0 016.5 3H19v18H6.5A2.5 2.5 0 014 18.5z"/><path d="M8 7h7M8 11h7"/></svg>',
  edit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 20h4l10-10a2.8 2.8 0 10-4-4L4 16z"/></svg>',
  execute: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="M7 9l3 3-3 3M13 15h4"/></svg>',
  search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l4 4"/></svg>',
  fetch: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3v12M7 10l5 5 5-5"/><path d="M4 19h16"/></svg>',
  think: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 18h6M10 21h4"/><path d="M12 3a6 6 0 00-3.5 10.9c.4.3.5.7.5 1.1h6c0-.4.1-.8.5-1.1A6 6 0 0012 3z"/></svg>',
  other: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M14.7 6.3a4 4 0 01-5.4 5.4L4 17v3h3l5.3-5.3a4 4 0 015.4-5.4l-2.5 2.5 2 2 2.5-2.5z"/></svg>',
};

const STATUS_TEXT = { pending: '等待中', in_progress: '执行中', completed: '完成', failed: '失败' };

function toolBodyHtml(tool) {
  const parts = [];
  for (const c of tool.content || []) {
    if (!c || typeof c !== 'object') continue;
    if (c.type === 'content' && c.content && c.content.type === 'text') parts.push(esc(c.content.text));
    else if (c.type === 'content' && c.content && c.content.type === 'image') parts.push('<span class="meta">[图片]</span>');
    else if (c.type === 'diff') {
      const oldLines = String(c.oldText || '').split('\n').map((l) => `<span class="del">- ${esc(l)}</span>`).join('\n');
      const newLines = String(c.newText || '').split('\n').map((l) => `<span class="add">+ ${esc(l)}</span>`).join('\n');
      parts.push(`<span class="meta">${esc(c.path || '')}</span>\n${oldLines}\n${newLines}`);
    } else if (c.type === 'terminal') parts.push('<span class="meta">[终端输出]</span>');
  }
  if (!parts.length && tool.rawInput !== undefined && tool.rawInput !== null) {
    try { parts.push(esc(JSON.stringify(tool.rawInput, null, 2))); } catch { /* ignore */ }
  }
  if (!parts.length && tool.rawOutput !== undefined && tool.rawOutput !== null) {
    try { parts.push(esc(typeof tool.rawOutput === 'string' ? tool.rawOutput : JSON.stringify(tool.rawOutput, null, 2))); } catch { /* ignore */ }
  }
  return parts.join('\n');
}

function updateToolState(stateEl, status) {
  if (status === 'completed') stateEl.innerHTML = '<span class="check">✓</span>';
  else if (status === 'failed') stateEl.innerHTML = '<span class="cross">✕</span>';
  else if (status === 'in_progress') stateEl.innerHTML = '<span class="spin"></span>';
  else stateEl.innerHTML = '<span class="wait">•</span>';
}

function toolElement(tool) {
  const wrap = el('div', 'tool');
  wrap.dataset.status = tool.status || 'pending';
  const head = el('button', 'tool-head');
  head.type = 'button';
  head.innerHTML = `
    <span class="tool-glyph">${TOOL_ICONS[tool.toolKind] || TOOL_ICONS.other}</span>
    <span class="tool-main">
      <span class="tool-title">${esc(tool.title || '工具调用')}</span>
      <span class="tool-sub">${esc(tool.name || tool.toolKind || 'tool')} · ${STATUS_TEXT[tool.status] || tool.status || '执行中'}</span>
    </span>
    <span class="tool-state"></span>`;
  const stateEl = head.querySelector('.tool-state');
  const body = el('div', 'tool-body');
  const bodyHtml = toolBodyHtml(tool);
  body.innerHTML = bodyHtml;
  body.hidden = !bodyHtml;
  head.addEventListener('click', () => {
    if (!body.innerHTML) return;
    body.hidden = !body.hidden;
  });
  wrap.append(head, body);
  updateToolState(stateEl, tool.status);
  return wrap;
}

/* ------------------------------------------------------------------ */
/* rendering                                                           */
/* ------------------------------------------------------------------ */

function renderItem(item) {
  let node;
  if (item.kind === 'user') {
    node = el('div', 'msg user');
    node.append(el('div', 'bubble', esc(item.text).replace(/\n/g, '<br/>')));
  } else if (item.kind === 'thought') {
    node = el('div', 'msg thought');
    node.innerHTML = `<span class="thought-tag">THINKING</span><span class="thought-text">${esc(item.text)}</span>`;
  } else if (item.kind === 'tool') {
    node = toolElement(item);
  } else if (item.kind === 'error') {
    node = el('div', 'msg error', esc(item.text));
  } else {
    node = el('div', 'msg assistant');
    node.append(el('div', 'body', mdToHtml(item.text || '')));
  }
  if (item.id) nodeById.set(item.id, node);
  return node;
}

function renderAll() {
  nodeById.clear();
  ui.thread.innerHTML = '';
  for (const item of state.items) ui.thread.append(renderItem(item));
  ui.hero.hidden = state.items.length > 0;
  renderTyping();
  updateHeader();
  requestAnimationFrame(() => scrollToBottom(false));
}

function appendItemInner(item) {
  state.items.push(item);
  const node = renderItem(item);
  ui.thread.append(node);
  ui.hero.hidden = true;
  removeTyping();
  renderTyping();
  if (nearBottom()) scrollToBottom(true);
}

function appendItem(item) {
  if (item.kind === 'user') {
    const pending = state.items.find((i) => i.id === 'pending');
    if (pending && pending.text === item.text) {
      const idx = state.items.indexOf(pending);
      state.items.splice(idx, 1);
      const node = nodeById.get('pending');
      if (node) {
        nodeById.delete('pending');
        nodeById.set(item.id, node);
      }
      state.items.push(item);
      renderTyping();
      if (nearBottom()) scrollToBottom(true);
      return;
    }
  }
  appendItemInner(item);
}

function removeTyping() {
  const t = ui.thread.querySelector('.msg.assistant.typing');
  if (t) t.remove();
}

function renderTyping() {
  removeTyping();
  if (!state.running) return;
  const node = el('div', 'msg assistant typing');
  node.innerHTML = '<div class="thinking"><i></i><i></i><i></i></div>';
  ui.thread.append(node);
}

function nearBottom() {
  const s = ui.scroller;
  return s.scrollHeight - s.scrollTop - s.clientHeight < 140;
}

function scrollToBottom(smooth) {
  const s = ui.scroller;
  s.scrollTo({ top: s.scrollHeight, behavior: smooth ? 'smooth' : 'auto' });
}

/* model options can be a two-level tree */
function flatOptions(option) {
  const out = [];
  const walk = (items, group) => {
    for (const item of items || []) {
      if (Array.isArray(item.options)) walk(item.options, item.group || item.name || group);
      else out.push({ value: item.value, name: item.name, description: item.description || '', group: item.group || group || '' });
    }
  };
  walk(option && option.options);
  return out;
}

function currentChoice(option) {
  if (!option) return null;
  return flatOptions(option).find((o) => o.value === option.currentValue) || null;
}

function shortModel(name) {
  if (!name) return '模型';
  return String(name).replace(/^DeepSeek[-\s]*/i, '').replace(/\s*\(.*\)$/, '');
}

function shortPath(p) {
  if (!p) return '';
  const parts = p.split(/[\\/]/).filter(Boolean);
  return parts.length > 2 ? '…/' + parts.slice(-2).join('/') : p;
}

function updateHeader() {
  const model = state.configOptions.find((o) => o.category === 'model' || o.id === 'model');
  const effort = state.configOptions.find((o) => o.category === 'thought_level' || /effort|reason/i.test(o.id));
  if (model) {
    ui.modelName.textContent = shortModel(currentChoice(model)?.name || String(model.currentValue || '模型'));
    ui.modelChip.hidden = false;
  } else ui.modelChip.hidden = true;

  ui.title.textContent = state.title || (state.sessionId ? '会话' : 'DeepSeek Harness');
  let sub;
  if (!state.connected) sub = '正在连接电脑…';
  else if (state.readonly) sub = '历史记录 · 只读';
  else if (!state.sessionId) sub = '未打开会话';
  else if (state.running) sub = 'Harness 正在工作';
  else sub = shortPath(state.cwd || '');
  ui.sub.textContent = sub;

  $('#connState').textContent = state.connected ? (state.demo ? '演示模式' : '已连接电脑') : '连接断开，重试中…';
  $('#connState').className = state.connected ? '' : 'offline';
  $('#modelRowValue').textContent = model ? shortModel(currentChoice(model)?.name || String(model.currentValue)) : '—';
  $('#effortRowValue').textContent = effort ? (currentChoice(effort)?.name || String(effort.currentValue)) : '—';

  ui.send.classList.toggle('running', state.running);
  ui.send.disabled = !state.connected;
  ui.input.placeholder = state.readonly
    ? '只读查看 · 点上方继续后可发送'
    : (state.running ? '可以中断，也可以继续输入…' : '给 Harness 发消息…');

  const status = $('#heroStatus');
  const statusText = $('#heroStatusText');
  if (status) status.className = 'pulse ' + (state.connected ? 'live' : 'dead');
  if (statusText) statusText.textContent = state.connected ? (state.demo ? '演示模式 · 数据是假的' : '已连接电脑') : '正在连接电脑…';

  $('#drawerAddr').textContent = location.origin;
  $('#composerHint').textContent = window.innerWidth >= 700 ? 'Enter 发送 · Shift + Enter 换行' : '回车换行 · 点箭头发送';

  renderPlan();
  renderUsage();
}

function renderPlan() {
  const plan = state.plan;
  if (!plan || !plan.entries || !plan.entries.length) { ui.planStrip.hidden = true; return; }
  const done = plan.entries.filter((e) => e.status === 'completed').length;
  const active = plan.entries.find((e) => e.status === 'in_progress');
  ui.planStrip.hidden = false;
  ui.planText.textContent = active ? active.content : (done === plan.entries.length ? '计划已完成' : '执行计划');
  ui.planCount.textContent = `${done}/${plan.entries.length}`;
}

function renderUsage() {
  if (!state.usage || !state.usage.size) { ui.usage.hidden = true; return; }
  const pct = Math.min(100, Math.round((state.usage.used / state.usage.size) * 100));
  ui.usage.hidden = false;
  ui.usageFill.style.width = pct + '%';
  ui.usageText.textContent = `上下文 ${pct}% · ${state.usage.used.toLocaleString()} / ${state.usage.size.toLocaleString()} tokens`;
}

/* ------------------------------------------------------------------ */
/* websocket                                                           */
/* ------------------------------------------------------------------ */

function connect() {
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  let ws;
  try { ws = new WebSocket(`${proto}//${location.host}/ws`); }
  catch { setTimeout(connect, 1500); return; }
  state.ws = ws;

  ws.onopen = () => {
    state.retry = 0;
    state.connected = true;
    state.lastMessageAt = Date.now();
    updateHeader();
    ws.send(JSON.stringify({ op: 'attach' }));
    ws.send(JSON.stringify({ op: 'sessions' }));
    ws.send(JSON.stringify({ op: 'workspaces' }));
  };

  ws.onmessage = (event) => {
    state.lastMessageAt = Date.now();
    let msg;
    try { msg = JSON.parse(event.data); } catch { return; }
    handleMessage(msg);
  };

  ws.onclose = () => {
    state.connected = false;
    updateHeader();
    state.retry = Math.min(state.retry + 1, 6);
    setTimeout(connect, Math.min(8000, 600 * 2 ** state.retry));
  };
  ws.onerror = () => { try { ws.close(); } catch { /* ignore */ } };
}

function send(obj) {
  if (!state.ws || state.ws.readyState !== WebSocket.OPEN) { toast('连接已断开，正在重连…'); connect(); return; }
  state.ws.send(JSON.stringify(obj));
}

function handleMessage(msg) {
  switch (msg.t) {
    case 'hello':
    case 'snapshot':
      state.demo = !!msg.demo;
      if (msg.session) applySession(msg.session);
      else { state.items = []; state.sessionId = null; renderAll(); }
      updateHeader();
      break;
    case 'session':
      applySession(msg.session);
      break;
    case 'item':
      appendItem(msg.item);
      break;
    case 'patch': {
      const item = state.items.find((i) => i.id === msg.id);
      if (!item) break;
      item.text = msg.text;
      const node = nodeById.get(msg.id);
      if (node) {
        const body = node.querySelector('.body');
        if (body) body.innerHTML = mdToHtml(msg.text);
      }
      if (nearBottom()) scrollToBottom(true);
      break;
    }
    case 'tool': {
      const item = state.items.find((i) => i.id === msg.id);
      if (!item) break;
      Object.assign(item, msg.patch);
      const node = nodeById.get(msg.id);
      if (node) {
        node.dataset.status = item.status;
        const sub = node.querySelector('.tool-sub');
        if (sub) sub.textContent = `${item.name || item.toolKind || 'tool'} · ${STATUS_TEXT[item.status] || item.status}`;
        const stateEl = node.querySelector('.tool-state');
        if (stateEl) updateToolState(stateEl, item.status);
        const title = node.querySelector('.tool-title');
        if (title) title.textContent = item.title;
        const body = node.querySelector('.tool-body');
        const html = toolBodyHtml(item);
        if (body && html) body.innerHTML = html;
      }
      break;
    }
    case 'status':
      state.running = !!msg.running;
      renderTyping();
      updateHeader();
      break;
    case 'plan':
      state.plan = msg.plan;
      renderPlan();
      break;
    case 'config':
      state.configOptions = msg.configOptions || [];
      updateHeader();
      break;
    case 'usage':
      state.usage = msg.usage;
      renderUsage();
      break;
    case 'title':
      state.title = msg.title;
      updateHeader();
      break;
    case 'sessions':
      state.sessions = msg.sessions || [];
      renderSessions();
      break;
    case 'workspaces':
      state.workspaces = msg.workspaces || [];
      renderWorkspaces();
      break;
    case 'history':
      applyHistory(msg.session);
      break;
    case 'permission':
      queuePermission(msg.request);
      break;
    case 'agent':
      if (msg.connected === false) {
        toast('电脑端 agent 已断开');
        state.connected = false;
        updateHeader();
      }
      break;
    case 'error':
      state.running = false;
      appendItem({ id: 'e' + Date.now(), kind: 'error', text: msg.message || '出错了' });
      renderTyping();
      updateHeader();
      break;
    default:
      break;
  }
}

function applySession(session) {
  state.sessionId = session.id;
  state.title = session.title || '新会话';
  state.cwd = session.cwd || '';
  state.items = session.items || [];
  state.running = !!session.running;
  state.configOptions = session.configOptions || [];
  state.usage = session.usage || null;
  state.plan = session.plan || null;
  state.readonly = false;
  ui.resumeBar.hidden = true;
  renderAll();
  closeDrawer();
}

function applyHistory(session) {
  state.sessionId = session.id;
  state.title = session.title || '未命名会话';
  state.cwd = session.cwd || '';
  state.items = session.items || [];
  state.running = false;
  state.usage = null;
  state.plan = null;
  state.readonly = true;
  ui.resumeBar.hidden = false;
  renderAll();
  closeDrawer();
  const total = session.total || state.items.length;
  if (total > state.items.length) toast(`仅显示最近 ${state.items.length} 条，共 ${total} 条`);
}

/* ------------------------------------------------------------------ */
/* composer                                                            */
/* ------------------------------------------------------------------ */

function autoGrow() {
  ui.input.style.height = 'auto';
  ui.input.style.height = Math.min(128, ui.input.scrollHeight) + 'px';
}

function submit() {
  const text = ui.input.value.trim();
  if (!text) return;
  if (!state.connected) { toast('还没连上电脑'); return; }
  if (state.readonly) { toast('历史记录只读，先点上方「继续这个会话」'); return; }
  if (!state.sessionId) { openNewSessionSheet(text); return; }
  if (state.running) { toast('先等当前任务结束，或点停止'); return; }
  send({ op: 'prompt', text });
  appendItem({ id: 'pending', kind: 'user', text });
  ui.input.value = '';
  autoGrow();
  ui.input.focus();
  if (navigator.vibrate) navigator.vibrate(6);
  requestAnimationFrame(() => scrollToBottom(true));
}

ui.input.addEventListener('input', autoGrow);
ui.input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey && window.innerWidth >= 700) { e.preventDefault(); submit(); }
});
ui.send.addEventListener('click', () => {
  if (state.running) { send({ op: 'cancel' }); toast('已请求停止'); return; }
  submit();
});
document.querySelectorAll('.chip').forEach((chip) => {
  chip.addEventListener('click', () => {
    ui.input.value = chip.dataset.fill || '';
    autoGrow();
    ui.input.focus();
  });
});

/* ------------------------------------------------------------------ */
/* drawer                                                              */
/* ------------------------------------------------------------------ */

function openDrawer() {
  ui.drawer.classList.add('open');
  ui.drawer.setAttribute('aria-hidden', 'false');
  ui.scrim.hidden = false;
  send({ op: 'sessions' });
}
function closeDrawer() {
  ui.drawer.classList.remove('open');
  ui.drawer.setAttribute('aria-hidden', 'true');
  ui.scrim.hidden = true;
}
$('#menuBtn').addEventListener('click', openDrawer);
$('#closeDrawer').addEventListener('click', closeDrawer);
ui.scrim.addEventListener('click', closeDrawer);

function renderWorkspaces() {
  ui.workspaceList.innerHTML = '';
  if (!state.workspaces.length) {
    ui.workspaceList.append(el('div', 'empty-note', '没有工作区记录'));
    return;
  }
  for (const w of state.workspaces) {
    const btn = el('button', 'workspace-chip');
    btn.innerHTML = `<span class="w-title">${esc(w.title || w.path)}</span><span class="w-path">${esc(shortPath(w.path))}</span>`;
    btn.title = w.path;
    btn.addEventListener('click', () => {
      closeDrawer();
      openNewSessionSheet('', w.path);
    });
    ui.workspaceList.append(btn);
  }
}

function renderSessions() {
  ui.sessionList.innerHTML = '';
  if (!state.sessions.length) {
    ui.sessionList.append(el('div', 'empty-note', '还没有会话，点上面新建一个。'));
    return;
  }
  for (const s of state.sessions) {
    const btn = el('button', 'session-item' + (s.id === state.sessionId && !state.readonly ? ' active' : ''));
    const ws = s.workspace ? `<span class="s-ws">${esc(s.workspace)}</span> · ` : '';
    btn.innerHTML = `<div class="s-title">${esc(s.title || '未命名会话')}</div><div class="s-meta">${ws}${esc(timeAgo(s.updatedAt))}</div>`;
    btn.addEventListener('click', () => {
      send({ op: 'history', sessionId: s.id });
      closeDrawer();
      toast('正在读取电脑上的记录…');
    });
    ui.sessionList.append(btn);
  }
}

$('#newSessionBtn').addEventListener('click', () => { closeDrawer(); openNewSessionSheet(''); });

/* ------------------------------------------------------------------ */
/* sheets                                                              */
/* ------------------------------------------------------------------ */

let sheetCloseOnScrim = true;
function openSheet(html, opts = {}) {
  ui.sheet.innerHTML = `<div class="sheet-grab"></div>${html}`;
  ui.sheetWrap.hidden = false;
  sheetCloseOnScrim = opts.closeOnScrim !== false;
}
function closeSheet() {
  ui.sheetWrap.hidden = true;
  ui.sheet.innerHTML = '';
}
ui.sheetWrap.addEventListener('click', (e) => {
  if (e.target === ui.sheetWrap && sheetCloseOnScrim) closeSheet();
});

function openNewSessionSheet(prefill, presetCwd) {
  const cwd = presetCwd || state.cwd || '';
  openSheet(`
    <h2>新建会话</h2>
    <p class="sheet-sub">Harness 会在这个目录里工作。填绝对路径，例如 <code>D:\\work\\project</code>。</p>
    <div class="cwd-field">
      <input id="cwdInput" value="${esc(cwd)}" placeholder="C:\\Users\\你\\Documents" autocapitalize="off" autocorrect="off" spellcheck="false" />
    </div>
    <button class="opt allow" id="cwdGo" style="justify-content:center;margin-top:12px">
      <span>开始新会话</span>
    </button>
    <div class="sheet-note">目录必须是电脑上已存在的绝对路径</div>
  `);
  const input = $('#cwdInput');
  setTimeout(() => input.focus(), 120);
  const go = () => {
    const dir = input.value.trim();
    if (!dir) { toast('请填写工作目录'); return; }
    send({ op: 'new', cwd: dir });
    closeSheet();
    if (prefill) { ui.input.value = prefill; autoGrow(); }
  };
  $('#cwdGo').addEventListener('click', go);
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
}

function openConfigSheet(only) {
  const options = state.configOptions.filter((o) => !only || o === only);
  if (!options.length) { toast('这个会话还没有可调选项'); return; }
  const parts = ['<h2>会话设置</h2><p class="sheet-sub">只影响这个会话，下一次提问生效。</p>'];
  for (const opt of options) {
    parts.push(`<div class="sheet-label">${esc(opt.name || opt.id)}</div>`);
    let group = null;
    for (const choice of flatOptions(opt)) {
      if (choice.group && choice.group !== group) {
        group = choice.group;
        parts.push(`<div class="sheet-group">${esc(group)}</div>`);
      }
      const cur = choice.value === opt.currentValue;
      parts.push(`<button class="opt ${cur ? 'current' : ''}" data-cfg="${esc(opt.id)}" data-val="${esc(choice.value)}">
        <span>${esc(choice.name)}</span>
        ${cur ? '<span class="tick">✓</span>' : `<span class="opt-kind">${esc(choice.description || '')}</span>`}
      </button>`);
    }
  }
  openSheet(parts.join(''));
  ui.sheet.querySelectorAll('[data-cfg]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.cfg;
      const value = btn.dataset.val;
      const option = state.configOptions.find((o) => o.id === id);
      if (option && option.type === 'boolean') send({ op: 'config', configId: id, value: value === 'true', boolean: true });
      else send({ op: 'config', configId: id, value });
      closeSheet();
    });
  });
}

ui.modelChip.addEventListener('click', () => openConfigSheet());
$('#resumeBtn').addEventListener('click', () => {
  if (!state.sessionId) return;
  send({ op: 'resume', sessionId: state.sessionId, cwd: state.cwd, title: state.title });
  toast('正在接管这个会话…');
});
$('#modelRow').addEventListener('click', () => openConfigSheet(null));
$('#effortRow').addEventListener('click', () => openConfigSheet(null));
$('#planBtn').addEventListener('click', () => {
  if (!state.plan) return;
  const rows = state.plan.entries.map((e) => {
    const cls = e.status === 'completed' ? 'done' : e.status === 'in_progress' ? 'active' : '';
    const mark = e.status === 'completed' ? '✓' : e.status === 'in_progress' ? '◔' : '○';
    return `<div class="plan-row ${cls}"><span class="mark">${mark}</span><span>${esc(e.content)}</span></div>`;
  }).join('');
  openSheet(`<h2>执行计划</h2><p class="sheet-sub">Harness 会按这个顺序推进，可以随时插话。</p>${rows}`);
});

/* permission */

function queuePermission(req) {
  state.permissionQueue.push(req);
  if (!state.pendingPermission) showNextPermission();
}

function showNextPermission() {
  const req = state.permissionQueue.shift();
  if (!req) { state.pendingPermission = null; closeSheet(); return; }
  state.pendingPermission = req;
  const tool = req.toolCall || {};
  const opts = (req.options || []).map((o) => {
    const reject = /reject|deny/i.test(o.kind || '');
    return `<button class="opt ${reject ? 'reject' : 'allow'}" data-opt="${esc(o.optionId)}">
      <span>${esc(o.name)}</span><span class="opt-kind">${esc(o.kind || '')}</span>
    </button>`;
  }).join('');
  const detail = tool.rawInput ? esc(JSON.stringify(tool.rawInput, null, 2)).slice(0, 600) : '';
  openSheet(`
    <h2>需要你确认</h2>
    <p class="sheet-sub">电脑上的 Harness 想执行一个操作，只有你点允许它才会继续。</p>
    <div class="sheet-tool">${esc(tool.title || tool.name || '未知操作')}${detail ? '\n\n' + detail : ''}</div>
    ${opts}
    <div class="sheet-note">点空白处不会自动放行；请求 5 分钟后自动取消。</div>
  `, { closeOnScrim: false });
  ui.sheet.querySelectorAll('[data-opt]').forEach((btn) => {
    btn.addEventListener('click', () => {
      send({ op: 'permission', reqId: req.reqId, optionId: btn.dataset.opt });
      state.pendingPermission = null;
      closeSheet();
      if (state.permissionQueue.length) setTimeout(showNextPermission, 220);
    });
  });
  if (navigator.vibrate) navigator.vibrate([8, 60, 8]);
}

/* copy code */
document.addEventListener('click', (e) => {
  const btn = e.target.closest('.code-copy');
  if (!btn) return;
  const text = btn.dataset.copy || '';
  navigator.clipboard?.writeText(text).then(() => {
    btn.textContent = '已复制';
    setTimeout(() => { btn.textContent = '复制'; }, 1400);
  }).catch(() => toast('复制失败'));
});

/* scroll affordance */
ui.scroller.addEventListener('scroll', () => {
  $('#scrollDown').hidden = !(!nearBottom() && state.items.length > 0);
}, { passive: true });
$('#scrollDown').addEventListener('click', () => scrollToBottom(true));

/* keyboard / viewport */
function syncViewport() {
  const vv = window.visualViewport;
  if (!vv) return;
  ui.app.style.height = vv.height + 'px';
  ui.app.style.top = vv.offsetTop + 'px';
  ui.app.style.bottom = 'auto';
  if (nearBottom()) scrollToBottom(false);
}
if (window.visualViewport) {
  window.visualViewport.addEventListener('resize', syncViewport);
  window.visualViewport.addEventListener('scroll', syncViewport);
}
ui.input.addEventListener('focus', () => setTimeout(() => { syncViewport(); scrollToBottom(false); }, 320));

/* heartbeat */
setInterval(() => {
  if (!state.ws || state.ws.readyState !== WebSocket.OPEN) return;
  send({ op: 'ping' });
}, 25000);

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible' && (!state.ws || state.ws.readyState > 1)) connect();
});

/* boot */
autoGrow();
updateHeader();
connect();
