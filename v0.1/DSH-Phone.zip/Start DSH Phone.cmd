@echo off
setlocal
chcp 65001 >nul
title DSH Phone
cd /d "%~dp0"

set "NODE="
where node >nul 2>nul && set "NODE=node"

if not defined NODE (
  for %%R in (
    "%LOCALAPPDATA%\Programs\DeepSeek Harness"
    "%ProgramFiles%\DeepSeek Harness"
    "E:\Deepseek Harness"
    "D:\Deepseek Harness"
    "C:\Deepseek Harness"
  ) do (
    if not defined NODE if exist "%%~R\resources\runtime\primary-runtime\dependencies\node\bin\node.exe" (
      set "NODE=%%~R\resources\runtime\primary-runtime\dependencies\node\bin\node.exe"
    )
  )
)

if not defined NODE (
  echo.
  echo   Node.js not found.
  echo   Install Node.js 20+ or the DeepSeek Harness desktop app first.
  echo.
  pause
  exit /b 1
)

"%NODE%" "%~dp0app\launcher.js" %*
set "CODE=%errorlevel%"
echo.
if not "%CODE%"=="0" echo   DSH Phone exited with code %CODE%.
echo   Window can be closed.
pause
